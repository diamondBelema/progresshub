from __future__ import annotations

import json
from typing import Any

import httpx

from app.core.config import settings

OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"
MODEL = "openai/gpt-3.5-turbo"

TONE_PROMPTS: dict[str, str] = {
    "coach": "You are a direct, no-nonsense coach. Be honest, push them, don't sugarcoat.",
    "guide": "You are a gentle, supportive guide. Be warm, encouraging, and compassionate.",
    "friend": "You are a funny, relatable friend. Be casual, use humor, keep it real.",
}


def _get_tone_system(tone: str) -> str:
    return TONE_PROMPTS.get(tone, TONE_PROMPTS["coach"])


async def call_openrouter(prompt: str, system: str) -> str:
    async with httpx.AsyncClient() as client:
        res = await client.post(
            OPENROUTER_URL,
            headers={
                "Authorization": f"Bearer {settings.openrouter_api_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": MODEL,
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": prompt},
                ],
            },
            timeout=30,
        )
        res.raise_for_status()
        return res.json()["choices"][0]["message"]["content"]


async def generate_plan(
    goal_name: str,
    target_amount: float,
    unit: str,
    deadline: str,
    constraints: list[dict[str, Any]],
    tone: str = "coach",
    achieved_so_far: float = 0,
) -> dict[str, Any]:
    system = (
        f"{_get_tone_system(tone)} You are a goal planning expert. "
        "Create a realistic daily plan that fits within the user's constraints. "
        "Return ONLY a JSON object. No other text."
    )

    constraints_text = "\n".join(
        [f"- {c.get('day', 'N/A')}: {c.get('available_hours', '?')}h available" for c in constraints]
    )

    context_line = f"Already achieved: {achieved_so_far} {unit}" if achieved_so_far else "Fresh goal."

    prompt = f"""
Goal: {goal_name}
Target: {target_amount} {unit}
Deadline: {deadline}
{context_line}

User's constraints:
{constraints_text}

Create a day-by-day plan. Return JSON:
{{
  "daily_target": <float>,
  "total_days": <int>,
  "schedule": [{{"day": <int>, "date": "<YYYY-MM-DD>", "target": <float>}}],
  "summary": "<1 sentence plan summary>"
}}
"""

    response = await call_openrouter(prompt, system)
    clean = response.strip().replace("```json", "").replace("```", "").strip()
    return json.loads(clean)


async def generate_identity(
    name: str, categories: list[str], goal: str = "", tone: str = "coach"
) -> str:
    system = f"{_get_tone_system(tone)} You are an identity architect for students."
    prompt = f"""
Student name: {name}
Focus areas: {', '.join(categories)}
Personal goal: {goal or 'Not specified'}

Write a 2-3 sentence identity profile in second person (You are...). Be specific, not generic.
"""
    return await call_openrouter(prompt, system)


async def analyze_pace(
    goal_name: str,
    target_amount: float,
    achieved_so_far: float,
    days_elapsed: int,
    total_days: int,
    checkin_history: list[dict[str, Any]],
    tone: str = "coach",
) -> dict[str, Any]:
    system = (
        f"{_get_tone_system(tone)} You are a progress analyst. "
        "Analyze the user's pace and predict their completion date. "
        "Return ONLY a JSON object. No other text."
    )

    history_text = "\n".join(
        [f"- Day {c.get('day', '?')}: {c.get('amount', 0)} {c.get('unit', 'units')}" for c in checkin_history[-10:]]
    )

    prompt = f"""
Goal: {goal_name}
Target: {target_amount}
Achieved so far: {achieved_so_far}
Days elapsed: {days_elapsed} of {total_days}

Recent check-ins:
{history_text}

Analyze pace. Return JSON:
{{
  "predicted_completion_pct": <0-100>,
  "on_track": <bool>,
  "predicted_days_remaining": <int>,
  "today_target": <float>,
  "message": "<1 sentence status>"
}}
"""
    response = await call_openrouter(prompt, system)
    clean = response.strip().replace("```json", "").replace("```", "").strip()
    return json.loads(clean)


async def generate_questions(
    identity: str, grades: dict[str, int], goal: str = "", tone: str = "coach"
) -> list[str]:
    system = f"""{_get_tone_system(tone)} You are a reflection coach for students.
Based on the student's identity, goal, and today's self-grades, generate exactly 3
personalized reflection questions. Make them specific and personal, not generic.
Return ONLY a JSON array of 3 strings. No other text."""

    grades_text = "\n".join([f"{k}: {v}/10" for k, v in grades.items()])
    prompt = f"""
Identity: {identity}
Goal: {goal or 'Not specified'}
Today's grades:
{grades_text}

Generate 3 reflection questions.
"""
    response = await call_openrouter(prompt, system)
    clean = response.strip().replace("```json", "").replace("```", "").strip()
    return json.loads(clean)


async def score_answers(
    identity: str, questions: list[str], answers: list[str], goal: str = "", tone: str = "coach"
) -> dict[str, Any]:
    system = f"""{_get_tone_system(tone)} You are a student progress coach.
Score the student's answers 0-100 based on self-awareness, honesty, and actionable thinking.
Return ONLY a JSON object like: {{"score": 75, "feedback": "One sentence of feedback here."}}
No other text."""

    qa_text = "\n".join([f"Q: {q}\nA: {a}" for q, a in zip(questions, answers)])
    prompt = f"""
Identity: {identity}
Goal: {goal or 'Not specified'}
{qa_text}
"""
    response = await call_openrouter(prompt, system)
    clean = response.strip().replace("```json", "").replace("```", "").strip()
    return json.loads(clean)


async def evolve_identity(
    current_identity: str, sessions: list[dict[str, Any]], goal: str = "", tone: str = "coach"
) -> str:
    system = f"{_get_tone_system(tone)} You are an identity architect."
    session_summary = "\n".join(
        [
            f"- {s['date']}: score {s['score']}, feedback: {s['feedback']}"
            for s in sessions[-7:]
        ]
    )
    prompt = f"""
Current identity: {current_identity}
Goal: {goal or 'Not specified'}

Last 7 sessions:
{session_summary}

Rewrite their identity to reflect their actual growth patterns. 2-3 sentences, second person.
"""
    return await call_openrouter(prompt, system)


async def generate_weekly_insight(
    identity: str, sessions: list[dict[str, Any]], goal: str = "", tone: str = "coach"
) -> str:
    system = f"{_get_tone_system(tone)} You are a student progress coach."
    session_summary = "\n".join(
        [f"- {s['date']}: score {s['score']}, feedback: {s['feedback']}" for s in sessions]
    )
    prompt = f"""
Identity: {identity}
Goal: {goal or 'Not specified'}

Sessions this week:
{session_summary}

Write a 2-3 sentence weekly insight. Be specific about what's improving and what's slipping.
"""
    return await call_openrouter(prompt, system)


async def detect_patterns(identity: str, sessions: list[dict[str, Any]]) -> str | None:
    if len(sessions) < 5:
        return None
    system = """You are a pattern recognition coach for students.
Look at the student's session data and identify one specific, non-obvious pattern.
Be concrete: name the exact categories involved and what triggers what.
One sentence only. If no clear pattern exists, return exactly: NONE"""

    session_summary = "\n".join(
        [f"- {s['date']}: score {s['score']}, grades: {s['grades']}" for s in sessions]
    )
    prompt = f"""
Identity: {identity}

Recent sessions:
{session_summary}

Identify one specific pattern.
"""
    result = await call_openrouter(prompt, system)
    return None if result.strip() == "NONE" else result.strip()


async def generate_challenge(
    identity: str, grades: dict[str, int], goal: str = "", tone: str = "coach"
) -> dict[str, str]:
    system = f"{_get_tone_system(tone)} You are a student coach."
    grades_text = "\n".join([f"{k}: {v}/10" for k, v in grades.items()])
    prompt = f"""
Identity: {identity}
Goal: {goal or 'Not specified'}
Today's grades:
{grades_text}

Generate a 3-day micro challenge for their weakest area.
Return ONLY a JSON object like:
{{"category": "Mental Health", "challenge": "Spend 10 minutes journaling before bed for the next 3 days."}}
"""
    response = await call_openrouter(prompt, system)
    clean = response.strip().replace("```json", "").replace("```", "").strip()
    return json.loads(clean)
