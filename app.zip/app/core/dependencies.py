from fastapi import Request


async def get_current_user(request: Request):
    user_id = request.cookies.get("user_id")
    if not user_id:
        return None
    return {"$id": user_id}
