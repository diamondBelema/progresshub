from __future__ import annotations

from typing import Any

from htmy import Component, Context, html
from app.components.ui import Card, Text
from app.utils.cn import cn

from app.schemas.checkin import CheckIn


class ProgressLogList:
    def __init__(self, checkins: list[CheckIn], class_: str | None = None, **kwargs: Any) -> None:
        self._checkins = checkins
        self._class = class_
        self._kwargs = kwargs

    def htmy(self, context: Context) -> Component:
        if not self._checkins:
            return Text("The ledger\u2019s empty. Log today\u2019s number to start the trail.", muted=True, size="sm")

        return html.div(
            *[
                Card(
                    html.div(
                        html.div(
                            html.span(f"+{c.amount}", class_="text-mint-400 font-medium font-mono"),
                            html.span(c.unit, class_="text-paper-400 text-sm"),
                            html.span(f"Energy: {c.energy}", class_="text-paper-500 text-xs ml-4"),
                            class_="flex items-center gap-2",
                        ),
                        *([Text(f"\u2014 {c.note}", muted=True, size="sm")] if c.note else []),
                        *([Text(f"Blocked: {c.blocker}", muted=True, size="sm")] if c.blocker else []),
                    ),
                    variant="default", padding="md",
                    class_="mb-3",
                )
                for c in self._checkins
            ],
            class_=cn(self._class or ""),
            **self._kwargs,
        )
